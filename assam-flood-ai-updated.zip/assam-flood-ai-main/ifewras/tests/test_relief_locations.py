"""Tests for the assistant's relief-camp lookup, kit-delivery status and site-guide answers."""
import os
import sys
import unittest

backend_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "backend")
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from app.assistant import nlp, tools
from app.scenarios.scenario_manager import scenario_manager
from app.stage3_relief import delivery_tracker


class TestDeliveryTracker(unittest.TestCase):
    def test_haversine_known_distance(self):
        # One degree of latitude is ~111 km.
        self.assertAlmostEqual(delivery_tracker.haversine_km([26.0, 91.0], [27.0, 91.0]), 111.2, delta=0.5)

    def test_kits_not_needed_before_flooding(self):
        scenario_manager.compute_hour(0)
        r = tools.get_relief_locations()
        self.assertEqual(set(r["status_counts"]), {"NOT_NEEDED_YET"})

    def test_kits_move_from_en_route_to_reached(self):
        seen = set()
        for hour in range(0, scenario_manager.max_hour + 1):
            scenario_manager.compute_hour(hour)
            seen |= set(tools.get_relief_locations()["status_counts"])
        self.assertIn("EN_ROUTE", seen)
        self.assertTrue({"REACHED", "REACHED_PARTIAL"} & seen)

    def test_kit_status_is_never_reached_before_release(self):
        scenario_manager.compute_hour(72)
        first = scenario_manager.first_flood_hours()
        for hour in (10, 30, 50, 72):
            scenario_manager.compute_hour(hour)
            for e in tools.get_relief_locations()["villages"]:
                vid = next(v["village_id"] for v in scenario_manager.get_full_pipeline_state()["stage3"]["ranked_villages"]
                           if v["village_name"] == e["village"])
                if e["kits"]["status"] in ("REACHED", "REACHED_PARTIAL"):
                    self.assertGreater(hour + 1e-9, first[vid])
                    self.assertLessEqual(e["kits"]["reached_by_hour"], hour)


class TestReliefLocationsTool(unittest.TestCase):
    def setUp(self):
        scenario_manager.compute_hour(40)

    def test_village_lookup_lists_designated_camp_first(self):
        r = tools.get_relief_locations("Mandia")
        self.assertEqual(r["scope"], "village")
        camps = r["villages"][0]["camps"]
        self.assertTrue(camps[0]["designated"])
        self.assertEqual(camps[0]["name"], "Mandia Block Development Relief Center")
        self.assertGreater(camps[0]["distance_km"], 0)
        self.assertLessEqual(len(camps), 3)

    def test_district_lookup(self):
        r = tools.get_relief_locations("Barpeta")
        self.assertEqual(r["scope"], "district")
        self.assertTrue(all(v["district"] == "Barpeta" for v in r["villages"]))

    def test_unknown_place(self):
        self.assertIn("error", tools.get_relief_locations("Atlantis"))

    def test_note_says_delivery_is_modelled(self):
        self.assertIn("modelled", tools.get_relief_locations()["note"])

    def test_village_tool_includes_camp_and_kits(self):
        v = tools.get_village("Salmora")
        self.assertIn("kit_delivery", v)
        self.assertTrue(v["relief_camps"])

    def test_tool_registered(self):
        names = {t["name"] for t in tools.TOOL_SCHEMAS}
        self.assertLessEqual({"get_relief_locations", "get_site_guide"}, names)
        self.assertEqual(names, set(tools.TOOL_FUNCTIONS))


class TestOfflineAnswers(unittest.TestCase):
    def setUp(self):
        scenario_manager.compute_hour(40)

    def test_intents(self):
        cases = {
            "nearest relief camps in Barpeta": "camps",
            "Has the relief kit reached Mandia Char?": "camps",
            "where is the nearest shelter": "camps",
            "kit reached in Majuli?": "camps",
            "relief kits delivered?": "camps",
            "मंडिया में शिविर कहाँ है": "camps",
            "what can this site do?": "site",
            # existing behaviour must not change
            "how many boats in Barpeta": "relief",
            "how is mandia char doing": "village",
            "relief reserves left": "relief",
        }
        for question, intent in cases.items():
            self.assertEqual(nlp.classify(question)[0], intent, question)

    def test_camp_answer_has_camp_and_kit_status(self):
        reply = nlp.answer("Has the relief kit reached Mandia Char?")["reply"]
        self.assertIn("Mandia Block Development Relief Center", reply)
        self.assertIn("Relief kits", reply)
        self.assertIn("modelled", reply)

    def test_site_answer_lists_pages(self):
        reply = nlp.answer("what can this site do?")["reply"]
        for page in ("Dashboard", "Map & Zones", "Relief", "Alerts", "Settings"):
            self.assertIn(page, reply)

    def test_village_answer_shows_kits(self):
        self.assertIn("Relief kits:", nlp.answer("status of Mandia Char")["reply"])


if __name__ == "__main__":
    unittest.main()
