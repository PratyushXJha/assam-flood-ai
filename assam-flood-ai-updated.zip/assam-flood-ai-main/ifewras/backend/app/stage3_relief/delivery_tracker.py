"""Relief camp lookup and kit-delivery status for the assistant.

Camps come from the village registry (each village has a designated relief camp with
coordinates). Delivery status is *modelled* from the allocation plan and the simulation clock:
kits are released the first hour a village floods and arrive after a mobilisation lag plus the
village's transit time. There is no field-confirmed delivery feed, so answers must say
"modelled" rather than "confirmed".
"""
import math
from typing import Any, Dict, List, Optional

from app.config import DELIVERY_MOBILISATION_HOURS, FLOODED_DEPTH_THRESHOLD_M

STATUS_LABELS = {
    "REACHED": "Reached",
    "REACHED_PARTIAL": "Reached (partial, restock queued)",
    "EN_ROUTE": "En route",
    "NOT_DISPATCHED": "Not dispatched (district reserve depleted)",
    "NOT_NEEDED_YET": "Not needed yet (village not flooded, kits on standby)",
}


def haversine_km(a: List[float], b: List[float]) -> float:
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 2 * 6371.0 * math.asin(math.sqrt(h))


def unique_camps(villages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Distinct relief camps with the villages each one is designated for."""
    camps: Dict[str, Dict[str, Any]] = {}
    for v in villages:
        c = camps.setdefault(v["nearest_camp_name"], {
            "name": v["nearest_camp_name"], "district": v["district"],
            "coords": list(v["nearest_camp_coords"]), "serves": []})
        c["serves"].append(v["village_name"])
    return list(camps.values())


def nearest_camps(village: Dict[str, Any], camps: List[Dict[str, Any]], limit: int = 3) -> List[Dict[str, Any]]:
    """Camps ranked by straight-line distance from the village; its designated camp is flagged."""
    here = [village["latitude"], village["longitude"]]
    ranked = sorted(camps, key=lambda c: haversine_km(here, c["coords"]))[:limit]
    designated = village["nearest_camp_name"]
    # The designated camp is always listed, even if another camp is marginally closer.
    if designated not in [c["name"] for c in ranked]:
        ranked = ranked[:limit - 1] + [next(c for c in camps if c["name"] == designated)]
    out = [{"name": c["name"], "district": c["district"], "distance_km": round(haversine_km(here, c["coords"]), 1),
            "designated": c["name"] == designated, "lat": c["coords"][0], "lon": c["coords"][1]} for c in ranked]
    out.sort(key=lambda c: (not c["designated"], c["distance_km"]))
    return out


def kit_delivery(plan: Dict[str, Any], hour: int, first_flood_hour: Optional[int],
                 transit_mins: float = 30) -> Dict[str, Any]:
    """Modelled delivery status of the relief kits allocated to one village at `hour`."""
    allocated = plan["allocated"]
    items = {
        "food_ration_kits": allocated["food_ration_kits"],
        "water_purification_kits": allocated["water_purification_kits"],
        "medical_teams": allocated["medical_teams"],
        "boats": allocated["sdrf_inflatable_boats"] + allocated["ndrf_motor_boats"],
    }
    shortfall = {k: v for k, v in plan["unmet_shortfall"].items() if v > 0}
    base = {"items": items, "shortfall": shortfall, "dispatch_status": plan["dispatch_status"]}

    if plan["estimated_flood_depth_m"] <= FLOODED_DEPTH_THRESHOLD_M or first_flood_hour is None:
        return {**base, "status": "NOT_NEEDED_YET", "label": STATUS_LABELS["NOT_NEEDED_YET"]}
    if not any(items.values()):
        return {**base, "status": "NOT_DISPATCHED", "label": STATUS_LABELS["NOT_DISPATCHED"]}

    lag = DELIVERY_MOBILISATION_HOURS.get(plan["access_mode"], 2.0)
    transit_h = transit_mins / 60.0
    eta_hour = first_flood_hour + lag + transit_h
    if hour >= eta_hour:
        status = "REACHED_PARTIAL" if shortfall else "REACHED"
        return {**base, "status": status, "label": STATUS_LABELS[status],
                "released_at_hour": first_flood_hour, "reached_by_hour": math.ceil(eta_hour)}
    return {**base, "status": "EN_ROUTE", "label": STATUS_LABELS["EN_ROUTE"],
            "released_at_hour": first_flood_hour, "expected_at_hour": math.ceil(eta_hour),
            "hours_to_go": max(1, math.ceil(eta_hour - hour)), "via": plan.get("transit_vehicle")}
